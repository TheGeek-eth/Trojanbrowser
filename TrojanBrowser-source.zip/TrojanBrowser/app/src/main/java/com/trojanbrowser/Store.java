package com.trojanbrowser;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.ArrayList;
import java.util.List;

/** Tiny wrapper around SharedPreferences: settings plus tab-separated row lists. */
final class Store {
    private final SharedPreferences p;

    Store(Context c) {
        p = c.getSharedPreferences("p", Context.MODE_PRIVATE);
    }

    static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim();
    }

    String str(String k, String d) { return p.getString(k, d); }
    void put(String k, String v) { p.edit().putString(k, v).apply(); }
    int num(String k, int d) { return p.getInt(k, d); }
    void putNum(String k, int v) { p.edit().putInt(k, v).apply(); }
    boolean flag(String k, boolean d) { return p.getBoolean(k, d); }
    void putFlag(String k, boolean v) { p.edit().putBoolean(k, v).apply(); }

    ArrayList<String[]> rows(String k) {
        ArrayList<String[]> r = new ArrayList<>();
        String s = p.getString(k, "");
        if (!s.isEmpty()) {
            for (String line : s.split("\n")) {
                if (!line.isEmpty()) r.add(line.split("\t", -1));
            }
        }
        return r;
    }

    void saveRows(String k, List<String[]> rows) {
        StringBuilder sb = new StringBuilder();
        for (String[] r : rows) {
            if (sb.length() > 0) sb.append('\n');
            sb.append(TextUtils.join("\t", r));
        }
        p.edit().putString(k, sb.toString()).apply();
    }

    // ---- history: {time, title, url}, newest first
    void addHistory(String title, String url) {
        ArrayList<String[]> h = rows("hist2");
        if (!h.isEmpty() && h.get(0).length > 2 && h.get(0)[2].equals(url)) h.remove(0);
        h.add(0, new String[]{String.valueOf(System.currentTimeMillis()), clean(title), clean(url)});
        while (h.size() > 1000) h.remove(h.size() - 1);
        saveRows("hist2", h);
    }

    void removeHistory(String time, String url) {
        ArrayList<String[]> h = rows("hist2");
        for (int i = 0; i < h.size(); i++) {
            String[] e = h.get(i);
            if (e.length > 2 && e[0].equals(time) && e[2].equals(url)) {
                h.remove(i);
                break;
            }
        }
        saveRows("hist2", h);
    }

    // ---- bookmarks: {title, url}
    boolean isBookmarked(String url) {
        for (String[] b : rows("bm")) if (b.length > 1 && b[1].equals(url)) return true;
        return false;
    }

    /** Returns true if the page is bookmarked after the call. */
    boolean toggleBookmark(String title, String url) {
        ArrayList<String[]> b = rows("bm");
        for (int i = 0; i < b.size(); i++) {
            if (b.get(i).length > 1 && b.get(i)[1].equals(url)) {
                b.remove(i);
                saveRows("bm", b);
                return false;
            }
        }
        b.add(0, new String[]{clean(title), clean(url)});
        saveRows("bm", b);
        return true;
    }

    void removeBookmark(String url) {
        ArrayList<String[]> b = rows("bm");
        for (int i = 0; i < b.size(); i++) {
            if (b.get(i).length > 1 && b.get(i)[1].equals(url)) {
                b.remove(i);
                break;
            }
        }
        saveRows("bm", b);
    }

    // ---- downloads: {id, name, uri, mime, status, size}
    void setDownload(String[] row) {
        ArrayList<String[]> d = rows("dl");
        for (int i = 0; i < d.size(); i++) {
            if (d.get(i)[0].equals(row[0])) {
                d.set(i, row);
                saveRows("dl", d);
                return;
            }
        }
        d.add(0, row);
        while (d.size() > 200) d.remove(d.size() - 1);
        saveRows("dl", d);
    }

    void removeDownload(String id) {
        ArrayList<String[]> d = rows("dl");
        for (int i = 0; i < d.size(); i++) {
            if (d.get(i)[0].equals(id)) {
                d.remove(i);
                break;
            }
        }
        saveRows("dl", d);
    }

    /** Moves the old v1.2 "visited sites" list into the new history format. */
    void migrate() {
        String old = p.getString("hist", null);
        if (old == null) return;
        ArrayList<String[]> h = rows("hist2");
        long now = System.currentTimeMillis();
        int i = 0;
        for (String u : old.split("\n")) {
            if (!u.isEmpty()) h.add(new String[]{String.valueOf(now - (++i) * 60000L), "", clean(u)});
        }
        saveRows("hist2", h);
        p.edit().remove("hist").remove("links").apply();
    }
}
