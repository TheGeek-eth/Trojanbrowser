package com.trojanbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;
    private EditText url, link;
    private Button proxyBtn, connect, goBtn;
    private ProgressBar progress;
    private TextView status;
    private LinearLayout panel;
    private Tunnel tunnel;
    private boolean loading;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        // --- top bar: [Trojan] [History] [address] [Go / stop]
        LinearLayout bar = new LinearLayout(this);
        proxyBtn = smallBtn("Trojan");
        Button histBtn = smallBtn("History");
        url = new EditText(this);
        url.setHint("Search or address");
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setImeOptions(EditorInfo.IME_ACTION_GO);
        goBtn = smallBtn("Go");
        bar.addView(proxyBtn, new LinearLayout.LayoutParams(WRAP, WRAP));
        bar.addView(histBtn, new LinearLayout.LayoutParams(WRAP, WRAP));
        bar.addView(url, new LinearLayout.LayoutParams(0, WRAP, 1f));
        bar.addView(goBtn, new LinearLayout.LayoutParams(WRAP, WRAP));

        // --- thin loading bar under the address bar
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setVisibility(View.GONE);

        // --- proxy panel: link field, [Connect] [Saved links]
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(8), 0, dp(8), dp(8));
        link = new EditText(this);
        link.setHint("Paste your trojan:// link");
        link.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        link.setText(prefs().getString("link", ""));          // stays until you change it
        connect = new Button(this);
        connect.setText("Connect");
        Button savedBtn = new Button(this);
        savedBtn.setText("Saved links");
        LinearLayout row = new LinearLayout(this);
        row.addView(connect, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(savedBtn, new LinearLayout.LayoutParams(WRAP, WRAP));
        status = new TextView(this);
        status.setText("Not connected");
        panel.addView(link, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
        panel.addView(status, new LinearLayout.LayoutParams(MATCH, WRAP));

        // --- web view
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String u, Bitmap icon) {
                if (!url.hasFocus()) url.setText(u);
                progress.setProgress(0);
                setLoading(true);
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                setLoading(false);
                if (u != null && (u.startsWith("http://") || u.startsWith("https://"))) {
                    remember("hist", u, 100);
                }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
            }
        });

        root.addView(bar, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));
        root.addView(panel, new LinearLayout.LayoutParams(MATCH, WRAP));
        root.addView(web, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        setContentView(root);

        proxyBtn.setOnClickListener(v -> panel.setVisibility(
                panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        histBtn.setOnClickListener(v -> showHistory());
        savedBtn.setOnClickListener(v -> showLinks());
        connect.setOnClickListener(v -> toggle());
        goBtn.setOnClickListener(v -> {
            if (loading) {
                web.stopLoading();
                setLoading(false);
            } else {
                go();
            }
        });
        url.setOnEditorActionListener((v, id, e) -> { go(); return true; });

        // a saved link exists -> connect right away
        if (!link.getText().toString().trim().isEmpty()) toggle();
    }

    private Button smallBtn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ----------------------------------------------------------------- storage

    private SharedPreferences prefs() {
        return getSharedPreferences("p", MODE_PRIVATE);
    }

    private ArrayList<String> load(String key) {
        ArrayList<String> r = new ArrayList<>();
        String s = prefs().getString(key, "");
        if (!s.isEmpty()) {
            for (String x : s.split("\n")) if (!x.isEmpty()) r.add(x);
        }
        return r;
    }

    private void save(String key, ArrayList<String> l) {
        prefs().edit().putString(key, TextUtils.join("\n", l)).apply();
    }

    /** Puts v at the top of the list (no duplicates, at most max entries). */
    private void remember(String key, String v, int max) {
        ArrayList<String> l = load(key);
        l.remove(v);
        l.add(0, v);
        while (l.size() > max) l.remove(l.size() - 1);
        save(key, l);
    }

    // ----------------------------------------------------------------- history

    private void showHistory() {
        final ArrayList<String> h = load("hist");
        AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle("History");
        if (h.isEmpty()) {
            d.setMessage("Nothing here yet");
        } else {
            final String[] a = h.toArray(new String[0]);
            d.setItems(a, (x, i) -> {
                url.setText(a[i]);
                go();
            });
            d.setNeutralButton("Clear", (x, i) -> prefs().edit().remove("hist").apply());
        }
        d.show();
    }

    private static String linkName(String l) {
        int h = l.indexOf('#');
        if (h >= 0 && h < l.length() - 1) return Uri.decode(l.substring(h + 1));
        int at = l.lastIndexOf('@');
        return at >= 0 ? l.substring(at + 1) : l;
    }

    private void showLinks() {
        final ArrayList<String> ls = load("links");
        AlertDialog.Builder d = new AlertDialog.Builder(this).setTitle("Saved links (long-press to delete)");
        if (ls.isEmpty()) {
            d.setMessage("A link is saved here once it connects successfully");
            d.show();
            return;
        }
        final String[] names = new String[ls.size()];
        for (int k = 0; k < names.length; k++) names[k] = linkName(ls.get(k));
        d.setItems(names, (x, i) -> link.setText(ls.get(i)));
        final AlertDialog dlg = d.create();
        dlg.show();
        dlg.getListView().setOnItemLongClickListener((p, v, pos, id) -> {
            ls.remove(pos);
            save("links", ls);
            dlg.dismiss();
            showLinks();
            return true;
        });
    }

    // ---------------------------------------------------------------- browsing

    private void setLoading(boolean on) {
        loading = on;
        progress.setVisibility(on ? View.VISIBLE : View.GONE);
        goBtn.setText(on ? "\u2715" : "Go");
    }

    private void go() {
        String q = url.getText().toString().trim();
        if (q.isEmpty()) return;
        String target;
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) target = q;
        else if (!q.contains(" ") && q.contains(".")) target = "https://" + q;
        else target = "https://duckduckgo.com/?q=" + Uri.encode(q);
        web.loadUrl(target);
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(url.getWindowToken(), 0);
        web.requestFocus();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    // ------------------------------------------------------------------ proxy

    private void toggle() {
        if (tunnel != null) {
            disconnect();
            return;
        }
        final String l = link.getText().toString().trim();
        if (l.isEmpty()) {
            status.setText("Paste your trojan:// link first");
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            status.setText("Please update \"Android System WebView\" from Play Store");
            return;
        }
        prefs().edit().putString("link", l).apply();       // current link is kept until you change it
        connect.setEnabled(false);
        status.setText("Connecting...");
        final Tunnel t = new Tunnel();
        new Thread(() -> {
            try {
                final int localPort = t.start(l);
                ui.post(() -> onConnected(t, localPort, l));
            } catch (final Exception e) {
                t.stop();
                final String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                ui.post(() -> {
                    connect.setEnabled(true);
                    status.setText("Failed: " + msg);
                });
            }
        }).start();
    }

    private void onConnected(Tunnel t, int localPort, String l) {
        ProxyConfig cfg = new ProxyConfig.Builder()
                .addProxyRule("socks5://127.0.0.1:" + localPort)
                .build();
        ProxyController.getInstance().setProxyOverride(cfg, Runnable::run, () -> { });
        remember("links", l, 20);
        tunnel = t;
        connect.setEnabled(true);
        connect.setText("Disconnect");
        proxyBtn.setText("Trojan \u2713");
        status.setText("Connected - all browser traffic goes through the Trojan server");
        panel.setVisibility(View.GONE);
    }

    private void disconnect() {
        final Tunnel t = tunnel;
        tunnel = null;
        new Thread(t::stop).start();
        ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> { });
        connect.setText("Connect");
        proxyBtn.setText("Trojan");
        status.setText("Not connected");
    }

    @Override
    protected void onDestroy() {
        if (tunnel != null) {
            final Tunnel t = tunnel;
            tunnel = null;
            new Thread(t::stop).start();
        }
        super.onDestroy();
    }
}
