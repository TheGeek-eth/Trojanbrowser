package com.trojanbrowser;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebSettingsCompat;
import androidx.webkit.WebViewFeature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    // ---- Chrome-dark palette
    static final int BG = 0xFF202124, OMNI = 0xFF303134, CARD = 0xFF292A2D, LINE = 0xFF3C4043,
            TXT = 0xFFE8EAED, SUB = 0xFF9AA0A6, ACC = 0xFF8AB4F8, RED = 0xFFF28B82, GREEN = 0xFF81C995;
    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;
    static final String[] ENGINE_NAMES = {"Google", "DuckDuckGo", "Bing"};
    static final String[] ENGINE_URLS = {"https://www.google.com/search?q=",
            "https://duckduckgo.com/?q=", "https://www.bing.com/search?q="};
    static final String[] DEFAULT_SITES = {"https://www.youtube.com", "https://www.google.com",
            "https://en.wikipedia.org", "https://www.facebook.com", "https://github.com",
            "https://www.instagram.com", "https://x.com", "https://www.reddit.com"};
    static final int[] ZOOMS = {75, 85, 100, 115, 130, 150, 175};

    static final class Tab {
        WebView web;
        SwipeRefreshLayout holder;
        String title = "", url = "", pending, errorUrl;
        Bitmap thumb, icon;
        boolean ntp, desktop, loading;
        int progress;
        Tab parent;
    }

    abstract static class Watcher implements TextWatcher {
        abstract void changed(String s);

        @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
        @Override public void afterTextChanged(Editable e) { changed(e.toString()); }
    }

    private final Handler ui = new Handler(Looper.getMainLooper());
    private Store store;
    private final ArrayList<Tab> tabs = new ArrayList<>();
    private final ArrayList<View> pages = new ArrayList<>();
    private Tab cur;
    private boolean booting = true, programmatic, connecting;
    private String mobileUa, desktopUa;

    private FrameLayout rootFrame, content, customHost;
    private LinearLayout findBar, sugList, ntpGrid;
    private ScrollView ntp, sugScroll;
    private EditText omni, findInput;
    private TextView sec, backBtn, reloadBtn, tabCount, findCount, ntpStatus;
    private ProgressBar progress;
    private PopupWindow menuPopup;

    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;

    // Trojan state
    private Tunnel tunnel;
    private int localPort;
    private String tStatus = "Not connected";
    private int tColor = SUB;
    private EditText trojanLink;
    private TextView trojanBtn, trojanStatusView;

    // ================================================================ lifecycle

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        store = new Store(this);
        store.migrate();
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        initUserAgents();
        buildUi();
        restoreTabs();
        handleIntent(getIntent());

        final String saved = store.str("link", "").trim();
        if (saved.isEmpty()) {
            finishBoot();
        } else {
            startTrojan(saved);                       // auto-connect with the saved link
            ui.postDelayed(() -> {
                if (booting) {
                    toast("Trojan connection timed out - opening without it");
                    finishBoot();
                }
            }, 25000);
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i);
    }

    private void handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            while (!pages.isEmpty()) closePage();
            newTab(i.getDataString(), null, true);
        }
    }

    @Override
    protected void onPause() {
        saveTabs();
        CookieManager.getInstance().flush();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (tunnel != null) {
            final Tunnel t = tunnel;
            tunnel = null;
            new Thread(t::stop).start();
        }
        for (Tab t : tabs) t.web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (!pages.isEmpty()) { closePage(); return; }
        if (omni.hasFocus()) { unfocusOmni(); return; }
        if (findBar.getVisibility() == View.VISIBLE) { closeFind(); return; }
        if (tabBack()) return;
        moveTaskToBack(true);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 77) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private void initUserAgents() {
        String def = WebSettings.getDefaultUserAgent(this);
        mobileUa = def.replace("; wv", "").replace("Version/4.0 ", "");
        String ver = "120.0.0.0";
        Matcher m = Pattern.compile("Chrome/([0-9.]+)").matcher(def);
        if (m.find()) ver = m.group(1);
        desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/"
                + ver + " Safari/537.36";
    }

    // Tabs are loaded only after the Trojan connection attempt is over, so nothing leaks around it.
    private void finishBoot() {
        if (!booting) return;
        booting = false;
        if (cur != null && cur.pending != null) {
            String u = cur.pending;
            cur.pending = null;
            cur.web.loadUrl(u);
        }
        refreshUi();
    }

    // ================================================================ UI helpers

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, int sp, int color) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        return v;
    }

    private Drawable ripple() {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), null, new ColorDrawable(Color.WHITE));
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private TextView icon(String glyph, View.OnClickListener l) {
        TextView v = label(glyph, 20, TXT);
        v.setGravity(Gravity.CENTER);
        v.setMinWidth(dp(44));
        v.setMinHeight(dp(44));
        v.setBackground(ripple());
        v.setOnClickListener(l);
        return v;
    }

    private TextView textBtn(String text, View.OnClickListener l) {
        TextView v = label(text, 14, ACC);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(12), dp(10), dp(12), dp(10));
        v.setBackground(ripple());
        v.setOnClickListener(l);
        return v;
    }

    private TextView pill(String text, View.OnClickListener l) {
        TextView v = label(text, 15, BG);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(24), dp(12), dp(24), dp(12));
        v.setBackground(round(ACC, 24));
        v.setOnClickListener(l);
        return v;
    }

    private LinearLayout vlist() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private ScrollView scroll(View child) {
        ScrollView sv = new ScrollView(this);
        sv.addView(child, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    private void hideKb() {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(rootFrame.getWindowToken(), 0);
    }

    private void showKb(View v) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.showSoftInput(v, 0);
    }

    /** A list row: title, optional subtitle, optional trailing action glyph. */
    private View row(String title, String sub, View.OnClickListener click, String actionGlyph,
                     View.OnClickListener action) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), dp(8), dp(4), dp(8));
        r.setBackground(ripple());
        r.setOnClickListener(click);
        LinearLayout col = vlist();
        TextView t = label(title, 16, TXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(t);
        if (sub != null && !sub.isEmpty()) {
            TextView s2 = label(sub, 12, SUB);
            s2.setSingleLine(true);
            s2.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(s2);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        if (actionGlyph != null) {
            r.addView(icon(actionGlyph, action), new LinearLayout.LayoutParams(dp(44), dp(44)));
        } else {
            r.setPadding(dp(16), dp(12), dp(16), dp(12));
        }
        return r;
    }

    private View header(String text) {
        TextView v = label(text, 13, ACC);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(dp(16), dp(16), dp(16), dp(4));
        return v;
    }

    private View emptyView(String text) {
        TextView v = label(text, 15, SUB);
        v.setGravity(Gravity.CENTER);
        v.setPadding(dp(16), dp(48), dp(16), dp(48));
        return v;
    }

    /** Full-screen page above the browser (history, tabs, settings...). */
    private void showPage(String title, View body, View... actions) {
        LinearLayout pg = new LinearLayout(this);
        pg.setOrientation(LinearLayout.VERTICAL);
        pg.setBackgroundColor(BG);
        pg.setClickable(true);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(4), dp(4), dp(4), dp(4));
        top.addView(icon("\u2190", v -> closePage()), new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView tt = label(title, 20, TXT);
        tt.setPadding(dp(8), 0, 0, 0);
        top.addView(tt, new LinearLayout.LayoutParams(0, WRAP, 1f));
        for (View a : actions) top.addView(a, new LinearLayout.LayoutParams(WRAP, WRAP));
        pg.addView(top, new LinearLayout.LayoutParams(MATCH, WRAP));
        View div = new View(this);
        div.setBackgroundColor(LINE);
        pg.addView(div, new LinearLayout.LayoutParams(MATCH, dp(1)));
        pg.addView(body, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        rootFrame.addView(pg, new FrameLayout.LayoutParams(MATCH, MATCH));
        pages.add(pg);
    }

    private void closePage() {
        if (pages.isEmpty()) return;
        View p = pages.remove(pages.size() - 1);
        rootFrame.removeView(p);
        hideKb();
    }

    // ================================================================ main layout

    private void buildUi() {
        rootFrame = new FrameLayout(this);
        rootFrame.setBackgroundColor(BG);
        LinearLayout browser = vlist();

        // ---- toolbar: back | omnibox | tabs | menu
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setBackgroundColor(BG);
        toolbar.setPadding(dp(4), dp(4), dp(4), dp(4));

        backBtn = icon("\u2190", v -> tabBack());
        toolbar.addView(backBtn, new LinearLayout.LayoutParams(dp(40), dp(44)));

        omni = new EditText(this);
        omni.setBackground(null);
        omni.setSingleLine(true);
        omni.setTextSize(15);
        omni.setTextColor(TXT);
        omni.setHintTextColor(SUB);
        omni.setHint("Search or type web address");
        omni.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        omni.setImeOptions(EditorInfo.IME_ACTION_GO);
        omni.setPadding(0, 0, 0, 0);
        omni.setOnFocusChangeListener((v, focus) -> {
            if (focus) {
                programmatic = true;
                omni.setText(fullText());
                programmatic = false;
                omni.selectAll();
                sec.setText("\uD83D\uDD0D");
                showSuggestions("");
            } else {
                hideSuggestions();
                refreshOmni();
            }
        });
        omni.setOnEditorActionListener((v, id, e) -> {
            String q = omni.getText().toString();
            unfocusOmni();
            navigate(q);
            return true;
        });
        omni.addTextChangedListener(new Watcher() {
            @Override void changed(String s) {
                if (!programmatic && omni.hasFocus()) showSuggestions(s);
            }
        });

        sec = label("", 14, TXT);
        sec.setGravity(Gravity.CENTER);
        sec.setPadding(dp(12), 0, dp(8), 0);
        reloadBtn = icon("\u21BB", v -> reloadOrStop());

        LinearLayout pill = new LinearLayout(this);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setBackground(round(OMNI, 22));
        pill.addView(sec, new LinearLayout.LayoutParams(WRAP, MATCH));
        pill.addView(omni, new LinearLayout.LayoutParams(0, MATCH, 1f));
        pill.addView(reloadBtn, new LinearLayout.LayoutParams(dp(40), MATCH));
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(0, dp(42), 1f);
        plp.setMargins(dp(2), 0, dp(2), 0);
        toolbar.addView(pill, plp);

        FrameLayout tabsBtn = new FrameLayout(this);
        tabsBtn.setBackground(ripple());
        tabsBtn.setOnClickListener(v -> showTabs());
        tabCount = label("1", 12, TXT);
        tabCount.setGravity(Gravity.CENTER);
        tabCount.setTypeface(Typeface.DEFAULT_BOLD);
        GradientDrawable box = new GradientDrawable();
        box.setColor(Color.TRANSPARENT);
        box.setStroke(dp(2), TXT);
        box.setCornerRadius(dp(4));
        tabCount.setBackground(box);
        tabsBtn.addView(tabCount, new FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER));
        toolbar.addView(tabsBtn, new LinearLayout.LayoutParams(dp(44), dp(44)));

        final TextView menuBtn = icon("\u22EE", null);
        menuBtn.setOnClickListener(v -> showMenu(menuBtn));
        toolbar.addView(menuBtn, new LinearLayout.LayoutParams(dp(40), dp(44)));

        // ---- progress bar
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ColorStateList.valueOf(ACC));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        progress.setVisibility(View.INVISIBLE);

        // ---- find-in-page bar
        findBar = new LinearLayout(this);
        findBar.setGravity(Gravity.CENTER_VERTICAL);
        findBar.setBackgroundColor(CARD);
        findBar.setPadding(dp(12), 0, dp(4), 0);
        findBar.setVisibility(View.GONE);
        findInput = new EditText(this);
        findInput.setBackground(null);
        findInput.setSingleLine(true);
        findInput.setHint("Find in page");
        findInput.setHintTextColor(SUB);
        findInput.setTextColor(TXT);
        findInput.setTextSize(15);
        findInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        findInput.setOnEditorActionListener((v, id, e) -> { findStep(true); return true; });
        findInput.addTextChangedListener(new Watcher() {
            @Override void changed(String s) {
                if (cur == null) return;
                if (s.isEmpty()) {
                    cur.web.clearMatches();
                    findCount.setText("");
                } else {
                    cur.web.findAllAsync(s);
                }
            }
        });
        findCount = label("", 13, SUB);
        findBar.addView(findInput, new LinearLayout.LayoutParams(0, dp(44), 1f));
        findBar.addView(findCount, new LinearLayout.LayoutParams(WRAP, WRAP));
        findBar.addView(icon("\u2191", v -> findStep(false)), new LinearLayout.LayoutParams(dp(44), dp(44)));
        findBar.addView(icon("\u2193", v -> findStep(true)), new LinearLayout.LayoutParams(dp(44), dp(44)));
        findBar.addView(icon("\u2715", v -> closeFind()), new LinearLayout.LayoutParams(dp(44), dp(44)));

        // ---- content area: tab view, new-tab page, suggestions
        content = new FrameLayout(this);
        ntp = buildNtp();
        content.addView(ntp, new FrameLayout.LayoutParams(MATCH, MATCH));
        sugList = vlist();
        sugScroll = new ScrollView(this);
        sugScroll.setBackgroundColor(BG);
        sugScroll.addView(sugList, new ViewGroup.LayoutParams(MATCH, WRAP));
        sugScroll.setVisibility(View.GONE);
        content.addView(sugScroll, new FrameLayout.LayoutParams(MATCH, MATCH));

        browser.addView(toolbar, new LinearLayout.LayoutParams(MATCH, WRAP));
        browser.addView(progress, new LinearLayout.LayoutParams(MATCH, dp(3)));
        browser.addView(findBar, new LinearLayout.LayoutParams(MATCH, WRAP));
        browser.addView(content, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        rootFrame.addView(browser, new FrameLayout.LayoutParams(MATCH, MATCH));

        customHost = new FrameLayout(this);
        customHost.setBackgroundColor(Color.BLACK);
        customHost.setVisibility(View.GONE);
        rootFrame.addView(customHost, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(rootFrame);
    }

    // ---- new tab page
    private ScrollView buildNtp() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout col = vlist();
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(12), dp(56), dp(12), dp(24));
        TextView logo = label("Trojan Browser", 30, TXT);
        logo.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(logo, new LinearLayout.LayoutParams(WRAP, WRAP));
        ntpStatus = label("", 13, SUB);
        ntpStatus.setPadding(0, dp(6), 0, dp(24));
        col.addView(ntpStatus, new LinearLayout.LayoutParams(WRAP, WRAP));

        LinearLayout box = new LinearLayout(this);
        box.setGravity(Gravity.CENTER_VERTICAL);
        box.setBackground(round(OMNI, 24));
        box.setPadding(dp(18), 0, dp(18), 0);
        box.addView(label("\uD83D\uDD0D   Search or type web address", 15, SUB));
        box.setOnClickListener(v -> {
            omni.requestFocus();
            showKb(omni);
        });
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(MATCH, dp(48));
        blp.setMargins(dp(8), 0, dp(8), dp(28));
        col.addView(box, blp);

        ntpGrid = vlist();
        col.addView(ntpGrid, new LinearLayout.LayoutParams(MATCH, WRAP));
        sv.addView(col, new ViewGroup.LayoutParams(MATCH, WRAP));
        return sv;
    }

    private void refreshNtp() {
        ntpStatus.setText(connecting ? "Connecting to Trojan..."
                : tunnel != null ? "\u25CF Trojan connected" : "\u25CB Trojan not connected");
        ntpStatus.setTextColor(tunnel != null ? GREEN : SUB);
        ntpGrid.removeAllViews();
        ArrayList<String> sites = topSites();
        for (int i = 0; i < sites.size(); i += 4) {
            LinearLayout r = new LinearLayout(this);
            for (int j = i; j < i + 4; j++) {
                if (j < sites.size()) r.addView(tile(sites.get(j)), new LinearLayout.LayoutParams(0, WRAP, 1f));
                else r.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
            ntpGrid.addView(r, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
    }

    private View tile(final String site) {
        LinearLayout t = vlist();
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setPadding(0, dp(6), 0, dp(10));
        t.setBackground(ripple());
        String host = hostOf(site);
        TextView c = label(host.isEmpty() ? "?" : host.substring(0, 1).toUpperCase(), 20, TXT);
        c.setGravity(Gravity.CENTER);
        c.setBackground(round(OMNI, 28));
        t.addView(c, new LinearLayout.LayoutParams(dp(56), dp(56)));
        TextView n = label(host, 12, SUB);
        n.setSingleLine(true);
        n.setEllipsize(TextUtils.TruncateAt.END);
        n.setGravity(Gravity.CENTER);
        n.setPadding(dp(4), dp(6), dp(4), 0);
        t.addView(n, new LinearLayout.LayoutParams(MATCH, WRAP));
        t.setOnClickListener(v -> navigate(site));
        return t;
    }

    private ArrayList<String> topSites() {
        final HashMap<String, Integer> counts = new HashMap<>();
        for (String[] h : store.rows("hist2")) {
            if (h.length < 3) continue;
            String o = origin(h[2]);
            if (o != null) counts.merge(o, 1, Integer::sum);
        }
        ArrayList<String> out = new ArrayList<>(counts.keySet());
        Collections.sort(out, (x, y) -> counts.get(y) - counts.get(x));
        while (out.size() > 8) out.remove(out.size() - 1);
        for (String d : DEFAULT_SITES) {
            if (out.size() >= 8) break;
            boolean has = false;
            for (String o : out) if (hostOf(o).equals(hostOf(d))) has = true;
            if (!has) out.add(d);
        }
        return out;
    }

    private static String origin(String url) {
        Uri u = Uri.parse(url);
        String host = u.getHost(), sch = u.getScheme();
        if (host == null || !("http".equals(sch) || "https".equals(sch))) return null;
        return sch + "://" + host;
    }

    private static String hostOf(String url) {
        String h = Uri.parse(url).getHost();
        if (h == null) return url == null ? "" : url;
        return h.startsWith("www.") ? h.substring(4) : h;
    }

    private static boolean isHttp(String u) {
        return u != null && (u.startsWith("http://") || u.startsWith("https://"));
    }

    // ================================================================ state -> UI

    private String title(Tab t) {
        if (!t.title.isEmpty()) return t.title;
        return t.ntp || t.url.isEmpty() ? "New tab" : hostOf(t.url);
    }

    private String fullText() {
        return cur == null || cur.ntp ? "" : cur.url;
    }

    private void refreshOmni() {
        if (cur == null) return;
        programmatic = true;
        if (cur.ntp || cur.url.isEmpty()) {
            omni.setText("");
            sec.setText("\uD83D\uDD0D");
            sec.setTextColor(TXT);
        } else {
            omni.setText(isHttp(cur.url) ? hostOf(cur.url) : cur.url);
            sec.setText(cur.url.startsWith("https://") ? "\uD83D\uDD12" : "\u26A0");
            sec.setTextColor(cur.url.startsWith("http://") ? RED : TXT);
        }
        programmatic = false;
    }

    private void refreshProgress() {
        Tab t = cur;
        if (t == null) return;
        boolean busy = t.loading && !t.ntp;
        progress.setVisibility(busy ? View.VISIBLE : View.INVISIBLE);
        progress.setProgress(t.progress);
    }

    private void refreshUi() {
        Tab t = cur;
        if (t == null) return;
        tabCount.setText(tabs.size() > 99 ? ":D" : String.valueOf(tabs.size()));
        ntp.setVisibility(t.ntp ? View.VISIBLE : View.GONE);
        if (t.ntp) refreshNtp();
        backBtn.setAlpha(t.web.canGoBack() || t.parent != null ? 1f : 0.4f);
        boolean busy = t.loading && !t.ntp;
        reloadBtn.setText(busy ? "\u2715" : "\u21BB");
        reloadBtn.setVisibility(t.ntp ? View.GONE : View.VISIBLE);
        refreshProgress();
        if (!omni.hasFocus()) refreshOmni();
    }

    // ================================================================ tabs

    private Tab createTab(Tab parentTab) {
        final Tab t = new Tab();
        t.parent = parentTab;
        t.ntp = true;
        final WebView w = new WebView(this);
        t.web = w;
        w.setBackgroundColor(BG);

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportMultipleWindows(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUserAgentString(mobileUa);
        s.setTextZoom(store.num("zoom", 100));
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, store.flag("dark", true));
        }
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView v, String u, Bitmap fav) {
                t.loading = true;
                t.progress = 5;
                t.url = u == null ? "" : u;
                if (t.errorUrl != null && !t.errorUrl.equals(u)) t.errorUrl = null;
                if (t == cur) refreshUi();
            }

            @Override
            public void onPageFinished(WebView v, String u) {
                t.loading = false;
                t.progress = 100;
                String now = v.getUrl();
                if (now != null) t.url = now;
                String ttl = v.getTitle();
                t.title = ttl == null ? "" : ttl;
                if (t.errorUrl == null && isHttp(now)) store.addHistory(ttl, now);
                if (t == cur) refreshUi();
                saveTabs();
            }

            @Override
            public void doUpdateVisitedHistory(WebView v, String u, boolean isReload) {
                if (u != null && !u.startsWith("about:")) t.url = u;
                if (t == cur) refreshUi();
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String sch = r.getUrl().getScheme();
                if (sch == null || sch.equals("http") || sch.equals("https") || sch.equals("about")
                        || sch.equals("data") || sch.equals("blob") || sch.equals("javascript")
                        || sch.equals("file")) {
                    return false;
                }
                if (r.hasGesture()) openExternal(r.getUrl().toString());
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (!r.isForMainFrame()) return;
                String failing = r.getUrl().toString();
                t.errorUrl = failing;
                v.loadDataWithBaseURL(failing, errorHtml(failing, String.valueOf(e.getDescription())),
                        "text/html", "UTF-8", failing);
            }

            @Override
            public void onReceivedSslError(WebView v, final SslErrorHandler h, SslError e) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Your connection is not private")
                        .setMessage("The security certificate of " + hostOf(String.valueOf(e.getUrl()))
                                + " can't be trusted. Attackers might be trying to steal your information.")
                        .setPositiveButton("Proceed (unsafe)", (d, which) -> h.proceed())
                        .setNegativeButton("Back to safety", (d, which) -> h.cancel())
                        .setOnCancelListener(d -> h.cancel())
                        .show();
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                ui.post(() -> {
                    toast("This tab crashed and was closed");
                    closeTab(t);
                });
                return true;
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                t.progress = p;
                if (t == cur) refreshProgress();
            }

            @Override
            public void onReceivedTitle(WebView v, String ttl) {
                t.title = ttl == null ? "" : ttl;
            }

            @Override
            public void onReceivedIcon(WebView v, Bitmap ic) {
                t.icon = ic;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                showCustom(view, cb);
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams fp) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(fp.createIntent(), 77);
                } catch (Exception ex) {
                    fileCb = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture) return false;               // popups without a tap are blocked
                Tab nt = createTab(t);
                nt.ntp = false;
                select(nt);
                WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
                tr.setWebView(nt.web);
                resultMsg.sendToTarget();
                return true;
            }

            @Override
            public void onCloseWindow(WebView window) {
                for (Tab x : new ArrayList<>(tabs)) if (x.web == window) closeTab(x);
            }
        });

        w.setDownloadListener((durl, ua, cd, mime, len) ->
                Downloader.start(MainActivity.this, store, durl, ua, cd, mime, t.url, proxyPort()));

        w.setOnLongClickListener(v -> {
            WebView.HitTestResult hr = w.getHitTestResult();
            int type = hr.getType();
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE) {
                showLinkMenu(hr.getExtra(), null);
                return true;
            }
            if (type == WebView.HitTestResult.IMAGE_TYPE) {
                showLinkMenu(null, hr.getExtra());
                return true;
            }
            if (type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                Message m = new Handler(Looper.getMainLooper()) {
                    @Override
                    public void handleMessage(Message msg) {
                        showLinkMenu(msg.getData().getString("url"), msg.getData().getString("src"));
                    }
                }.obtainMessage();
                w.requestFocusNodeHref(m);
                return true;
            }
            return false;
        });

        w.setFindListener((active, matches, done) -> {
            if (t == cur) findCount.setText(matches == 0 ? "0/0" : (active + 1) + "/" + matches);
        });

        t.holder = new SwipeRefreshLayout(this);
        t.holder.addView(w, new ViewGroup.LayoutParams(MATCH, MATCH));
        t.holder.setColorSchemeColors(ACC);
        t.holder.setProgressBackgroundColorSchemeColor(CARD);
        t.holder.setOnChildScrollUpCallback((p0, child) -> w.getScrollY() > 0);
        t.holder.setOnRefreshListener(() -> {
            reloadTab(t);
            t.holder.setRefreshing(false);
        });

        tabs.add(t);
        return t;
    }

    private void select(Tab t) {
        if (omni != null && omni.hasFocus()) unfocusOmni();
        if (cur != null && cur != t) {
            capture(cur);
            content.removeView(cur.holder);
        }
        cur = t;
        if (t.holder.getParent() == null) content.addView(t.holder, 0, new FrameLayout.LayoutParams(MATCH, MATCH));
        if (t.pending != null && !booting) {
            String u = t.pending;
            t.pending = null;
            t.web.loadUrl(u);
        }
        hideSuggestions();
        if (findBar.getVisibility() == View.VISIBLE) closeFind();
        refreshUi();
        saveTabs();
    }

    private Tab newTab(String url, Tab parentTab, boolean select) {
        Tab t = createTab(parentTab);
        if (url != null) {
            t.ntp = false;
            t.url = url;
        }
        if (select) select(t);
        if (url != null) loadIn(t, url);
        refreshUi();
        saveTabs();
        return t;
    }

    private void closeTab(Tab t) {
        int i = tabs.indexOf(t);
        if (i < 0) return;
        boolean wasCur = t == cur;
        tabs.remove(i);
        content.removeView(t.holder);
        t.web.stopLoading();
        t.holder.removeAllViews();
        t.web.destroy();
        if (tabs.isEmpty()) {
            cur = null;
            newTab(null, null, true);
            return;
        }
        if (wasCur) {
            Tab next = t.parent != null && tabs.contains(t.parent) ? t.parent
                    : tabs.get(Math.min(i, tabs.size() - 1));
            cur = null;
            select(next);
        } else {
            refreshUi();
        }
        saveTabs();
    }

    private void closeAllTabs() {
        for (Tab t : tabs) {
            content.removeView(t.holder);
            t.web.stopLoading();
            t.holder.removeAllViews();
            t.web.destroy();
        }
        tabs.clear();
        cur = null;
        newTab(null, null, true);
    }

    private void saveTabs() {
        if (tabs.isEmpty()) return;
        ArrayList<String[]> r = new ArrayList<>();
        for (Tab t : tabs) {
            String u = t.ntp ? "" : (t.pending != null ? t.pending : Store.clean(t.url));
            r.add(new String[]{u, Store.clean(t.title)});
        }
        store.saveRows("tabs", r);
        store.putNum("active", Math.max(0, tabs.indexOf(cur)));
    }

    private void restoreTabs() {
        ArrayList<String[]> saved = store.rows("tabs");
        if (saved.isEmpty()) {
            select(createTab(null));
            return;
        }
        for (String[] r : saved) {
            Tab t = createTab(null);
            String u = r.length > 0 ? r[0] : "";
            t.title = r.length > 1 ? r[1] : "";
            if (!u.isEmpty()) {
                t.ntp = false;
                t.url = u;
                t.pending = u;
            }
        }
        int a = store.num("active", 0);
        select(tabs.get(a >= 0 && a < tabs.size() ? a : 0));
    }

    private void capture(Tab t) {
        try {
            int w = t.web.getWidth();
            if (w <= 0 || t.ntp) return;
            int cw = (getResources().getDisplayMetrics().widthPixels - dp(36)) / 2;
            int ch = dp(140);
            Bitmap bm = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bm);
            float sc = cw / (float) w;
            c.scale(sc, sc);
            t.web.draw(c);
            t.thumb = bm;
        } catch (Throwable ignored) {
        }
    }

    /** Back: page history first, then close a tab that was opened from another one. */
    private boolean tabBack() {
        Tab t = cur;
        if (t == null) return false;
        if (!t.ntp && t.web.canGoBack()) {
            t.web.goBack();
            return true;
        }
        if (t.parent != null && tabs.contains(t.parent)) {
            closeTab(t);
            return true;
        }
        return false;
    }

    // ================================================================ navigation

    private String resolve(String q) {
        if (q.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) return q;
        if (!q.contains(" ") && (q.contains(".") || q.startsWith("localhost"))
                && !q.startsWith(".") && !q.endsWith(".")) {
            return "https://" + q;
        }
        int i = store.num("engine", 0);
        if (i < 0 || i >= ENGINE_URLS.length) i = 0;
        return ENGINE_URLS[i] + Uri.encode(q);
    }

    private void navigate(String input) {
        String q = input == null ? "" : input.trim();
        if (q.isEmpty() || cur == null) return;
        String target = resolve(q);
        cur.ntp = false;
        cur.errorUrl = null;
        cur.url = target;
        cur.title = "";
        loadIn(cur, target);
        refreshUi();
    }

    private void loadIn(Tab t, String u) {
        if (booting) {
            t.pending = u;
            if (t == cur) toast("Waiting for the Trojan connection...");
        } else {
            t.pending = null;
            t.web.loadUrl(u);
        }
    }

    private void reloadTab(Tab t) {
        if (t.ntp) return;
        if (t.pending != null && !booting) {
            String u = t.pending;
            t.pending = null;
            t.web.loadUrl(u);
        } else if (t.errorUrl != null) {
            String u = t.errorUrl;
            t.errorUrl = null;
            t.web.loadUrl(u);
        } else {
            t.web.reload();
        }
    }

    private void reloadOrStop() {
        Tab t = cur;
        if (t == null || t.ntp) return;
        if (t.loading) {
            t.web.stopLoading();
            t.loading = false;
            refreshUi();
        } else {
            reloadTab(t);
        }
    }

    private String errorHtml(String url, String desc) {
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{background:#202124;color:#e8eaed;font-family:sans-serif;padding:32px 24px}"
                + "h1{font-size:22px;font-weight:500}p{color:#9aa0a6;line-height:1.5}"
                + "a{color:#8ab4f8}</style></head><body><div style='font-size:64px'>:(</div>"
                + "<h1>This site can\u2019t be reached</h1><p><b>" + TextUtils.htmlEncode(hostOf(url))
                + "</b> didn\u2019t load. Check the address, your internet connection and the Trojan "
                + "connection (menu &rarr; Trojan connection).</p><p>" + TextUtils.htmlEncode(desc)
                + "</p><p><a href=\"" + TextUtils.htmlEncode(url) + "\">Reload</a></p></body></html>";
    }

    private void openExternal(String u) {
        try {
            Intent i = u.startsWith("intent:") ? Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, Uri.parse(u));
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            i.setComponent(null);
            i.setSelector(null);
            startActivity(i);
        } catch (Exception e) {
            toast("No app found to open this link");
        }
    }

    // ================================================================ omnibox

    private void unfocusOmni() {
        omni.clearFocus();
        hideKb();
        hideSuggestions();
        if (cur != null) cur.web.requestFocus();
    }

    private void hideSuggestions() {
        if (sugScroll != null) sugScroll.setVisibility(View.GONE);
    }

    private void showSuggestions(String text) {
        final String q = text.trim();
        String ql = q.toLowerCase();
        sugList.removeAllViews();
        if (!q.isEmpty()) {
            sugList.addView(sugRow("\uD83D\uDD0D", q, "", () -> { unfocusOmni(); navigate(q); }));
        }
        ArrayList<String> seen = new ArrayList<>();
        int n = 0;
        for (String[] b : store.rows("bm")) {
            if (n >= 4 || b.length < 2) continue;
            if (ql.isEmpty() || b[0].toLowerCase().contains(ql) || b[1].toLowerCase().contains(ql)) {
                final String u = b[1];
                seen.add(u);
                n++;
                sugList.addView(sugRow("\u2605", b[0].isEmpty() ? hostOf(u) : b[0], u,
                        () -> { unfocusOmni(); navigate(u); }));
            }
        }
        n = 0;
        for (String[] h : store.rows("hist2")) {
            if (n >= 6 || h.length < 3 || seen.contains(h[2])) continue;
            if (ql.isEmpty() || h[1].toLowerCase().contains(ql) || h[2].toLowerCase().contains(ql)) {
                final String u = h[2];
                seen.add(u);
                n++;
                sugList.addView(sugRow("\uD83D\uDD52", h[1].isEmpty() ? hostOf(u) : h[1], u,
                        () -> { unfocusOmni(); navigate(u); }));
            }
        }
        sugScroll.setVisibility(View.VISIBLE);
    }

    private View sugRow(String glyph, String title, String sub, final Runnable act) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(12), dp(8), dp(12), dp(8));
        r.setBackground(ripple());
        TextView g = label(glyph, 16, SUB);
        g.setGravity(Gravity.CENTER);
        r.addView(g, new LinearLayout.LayoutParams(dp(32), WRAP));
        LinearLayout col = vlist();
        TextView t = label(title, 15, TXT);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(t);
        if (!sub.isEmpty()) {
            TextView s2 = label(sub, 12, SUB);
            s2.setSingleLine(true);
            s2.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(s2);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, WRAP, 1f));
        r.setOnClickListener(v -> act.run());
        return r;
    }

    // ================================================================ find in page

    private void openFind() {
        if (cur == null || cur.ntp) return;
        findBar.setVisibility(View.VISIBLE);
        findInput.requestFocus();
        showKb(findInput);
    }

    private void findStep(boolean forward) {
        if (cur != null) cur.web.findNext(forward);
    }

    private void closeFind() {
        findBar.setVisibility(View.GONE);
        findInput.setText("");
        findCount.setText("");
        if (cur != null) cur.web.clearMatches();
        hideKb();
    }

    // ================================================================ menu

    private void showMenu(View anchor) {
        final Tab t = cur;
        final PopupWindow pw = new PopupWindow(this);
        menuPopup = pw;
        LinearLayout box = vlist();
        box.setBackground(round(0xFF2D2E30, 12));
        box.setPadding(0, dp(6), 0, dp(6));

        boolean bm = !t.ntp && store.isBookmarked(t.url);
        LinearLayout ir = new LinearLayout(this);
        TextView fwd = icon("\u2192", v -> {
            pw.dismiss();
            if (t.web.canGoForward()) t.web.goForward();
        });
        fwd.setAlpha(t.web.canGoForward() ? 1f : 0.4f);
        TextView star = icon(bm ? "\u2605" : "\u2606", v -> {
            pw.dismiss();
            toggleBookmark();
        });
        if (bm) star.setTextColor(ACC);
        TextView rl = icon(t.loading ? "\u2715" : "\u21BB", v -> {
            pw.dismiss();
            reloadOrStop();
        });
        ir.addView(fwd, new LinearLayout.LayoutParams(0, dp(46), 1f));
        ir.addView(star, new LinearLayout.LayoutParams(0, dp(46), 1f));
        ir.addView(rl, new LinearLayout.LayoutParams(0, dp(46), 1f));
        box.addView(ir, new LinearLayout.LayoutParams(MATCH, WRAP));
        View div = new View(this);
        div.setBackgroundColor(LINE);
        box.addView(div, new LinearLayout.LayoutParams(MATCH, dp(1)));

        addItem(box, pw, "New tab", "", SUB, () -> newTab(null, null, true));
        addItem(box, pw, "Bookmarks", "", SUB, this::showBookmarks);
        addItem(box, pw, "History", "", SUB, this::showHistory);
        addItem(box, pw, "Downloads", "", SUB, this::showDownloads);
        addItem(box, pw, "Share...", "", SUB, () -> share(t.url));
        addItem(box, pw, "Find in page", "", SUB, this::openFind);
        addItem(box, pw, "Desktop site", t.desktop ? "\u2713" : "", ACC, this::toggleDesktop);
        addItem(box, pw, "Print / Save as PDF", "", SUB, this::printPage);
        addItem(box, pw, "Settings", "", SUB, this::showSettings);
        addItem(box, pw, "Trojan connection", tunnel != null ? "Connected" : connecting ? "..." : "Off",
                tunnel != null ? GREEN : SUB, this::showTrojan);

        pw.setContentView(scroll(box));
        pw.setWidth(dp(250));
        pw.setHeight(WRAP);
        pw.setFocusable(true);
        pw.setOutsideTouchable(true);
        pw.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        pw.setElevation(dp(8));
        pw.showAsDropDown(anchor, dp(40) - dp(250), -dp(44));
    }

    private void addItem(LinearLayout box, final PopupWindow pw, String text, String right, int rightColor,
                         final Runnable act) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(16), 0, dp(16), 0);
        r.setBackground(ripple());
        r.addView(label(text, 15, TXT), new LinearLayout.LayoutParams(0, WRAP, 1f));
        if (!right.isEmpty()) r.addView(label(right, 13, rightColor));
        r.setOnClickListener(v -> {
            pw.dismiss();
            act.run();
        });
        box.addView(r, new LinearLayout.LayoutParams(MATCH, dp(46)));
    }

    private void toggleBookmark() {
        Tab t = cur;
        if (t.ntp || !isHttp(t.url)) {
            toast("This page can't be bookmarked");
            return;
        }
        boolean now = store.toggleBookmark(title(t), t.url);
        toast(now ? "Bookmark added" : "Bookmark removed");
    }

    private void toggleDesktop() {
        Tab t = cur;
        t.desktop = !t.desktop;
        t.web.getSettings().setUserAgentString(t.desktop ? desktopUa : mobileUa);
        toast(t.desktop ? "Desktop site" : "Mobile site");
        reloadTab(t);
    }

    private void share(String u) {
        if (cur != null && cur.ntp && (u == null || u.isEmpty())) {
            toast("Open a page first");
            return;
        }
        Intent s = new Intent(Intent.ACTION_SEND);
        s.setType("text/plain");
        s.putExtra(Intent.EXTRA_TEXT, u);
        startActivity(Intent.createChooser(s, "Share"));
    }

    private void printPage() {
        if (cur == null || cur.ntp) {
            toast("Open a page first");
            return;
        }
        try {
            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
            String job = title(cur);
            pm.print(job, cur.web.createPrintDocumentAdapter(job), new PrintAttributes.Builder().build());
        } catch (Exception e) {
            toast("Can't print this page");
        }
    }

    private void copy(String s) {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("url", s));
        toast("Copied");
    }

    // ---- long-press menu on links / images
    private void showLinkMenu(final String link, final String img) {
        final ArrayList<String> names = new ArrayList<>();
        final ArrayList<Runnable> acts = new ArrayList<>();
        final Tab from = cur;
        if (link != null && !link.isEmpty()) {
            names.add("Open in new tab");
            acts.add(() -> {
                newTab(link, from, false);
                toast("Opened in a new tab");
            });
            names.add("Copy link address");
            acts.add(() -> copy(link));
            names.add("Share link");
            acts.add(() -> share(link));
        }
        if (img != null && !img.isEmpty()) {
            names.add("Open image in new tab");
            acts.add(() -> {
                newTab(img, from, false);
                toast("Opened in a new tab");
            });
            names.add("Download image");
            acts.add(() -> Downloader.start(this, store, img, mobileUa, null, null,
                    from == null ? null : from.url, proxyPort()));
            names.add("Copy image address");
            acts.add(() -> copy(img));
        }
        if (names.isEmpty()) return;
        String ttl = link != null && !link.isEmpty() ? link : img;
        if (ttl.length() > 80) ttl = ttl.substring(0, 80) + "...";
        new AlertDialog.Builder(this).setTitle(ttl)
                .setItems(names.toArray(new String[0]), (d, i) -> acts.get(i).run())
                .show();
    }

    // ---- fullscreen video
    private void showCustom(View v, WebChromeClient.CustomViewCallback cb) {
        if (customView != null) {
            cb.onCustomViewHidden();
            return;
        }
        customView = v;
        customCb = cb;
        customHost.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        customHost.setVisibility(View.VISIBLE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    private void hideCustom() {
        if (customView == null) return;
        customHost.removeView(customView);
        customHost.setVisibility(View.GONE);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
    }

    // ================================================================ pages

    private void showTabs() {
        if (cur != null) capture(cur);
        LinearLayout grid = vlist();
        grid.setPadding(dp(6), dp(6), dp(6), dp(6));
        LinearLayout rowL = null;
        for (int i = 0; i < tabs.size(); i++) {
            if (i % 2 == 0) {
                rowL = new LinearLayout(this);
                grid.addView(rowL, new LinearLayout.LayoutParams(MATCH, WRAP));
            }
            rowL.addView(tabCard(tabs.get(i)), new LinearLayout.LayoutParams(0, WRAP, 1f));
        }
        if (tabs.size() % 2 == 1) rowL.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        showPage(tabs.size() + (tabs.size() == 1 ? " tab" : " tabs"), scroll(grid),
                textBtn("Close all", v -> {
                    closePage();
                    closeAllTabs();
                }),
                textBtn("+ New tab", v -> {
                    closePage();
                    newTab(null, null, true);
                }));
    }

    private View tabCard(final Tab t) {
        LinearLayout card = vlist();
        GradientDrawable bg = round(CARD, 12);
        if (t == cur) bg.setStroke(dp(2), ACC);
        card.setBackground(bg);
        card.setPadding(dp(2), dp(2), dp(2), dp(2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        lp.setMargins(dp(6), dp(6), dp(6), dp(6));
        card.setLayoutParams(lp);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(8), 0, 0, 0);
        View fav;
        if (t.icon != null) {
            ImageView iv = new ImageView(this);
            iv.setImageBitmap(t.icon);
            fav = iv;
        } else {
            TextView ltr = label(title(t).substring(0, 1).toUpperCase(), 12, SUB);
            ltr.setGravity(Gravity.CENTER);
            fav = ltr;
        }
        head.addView(fav, new LinearLayout.LayoutParams(dp(18), dp(18)));
        TextView tt = label(title(t), 13, TXT);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tt.setPadding(dp(8), 0, 0, 0);
        head.addView(tt, new LinearLayout.LayoutParams(0, WRAP, 1f));
        TextView x = icon("\u2715", v -> {
            closeTab(t);
            closePage();
            showTabs();
        });
        x.setTextSize(14);
        head.addView(x, new LinearLayout.LayoutParams(dp(36), dp(36)));
        card.addView(head, new LinearLayout.LayoutParams(MATCH, WRAP));

        ImageView th = new ImageView(this);
        th.setScaleType(ImageView.ScaleType.CENTER_CROP);
        th.setBackground(round(OMNI, 8));
        if (t.thumb != null && !t.ntp) th.setImageBitmap(t.thumb);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(MATCH, dp(140));
        tlp.setMargins(dp(6), 0, dp(6), dp(6));
        card.addView(th, tlp);

        card.setOnClickListener(v -> {
            closePage();
            select(t);
        });
        return card;
    }

    private String dayLabel(long ms) {
        if (DateUtils.isToday(ms)) return "Today";
        if (DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS)) return "Yesterday";
        return DateUtils.formatDateTime(this, ms, DateUtils.FORMAT_SHOW_DATE
                | DateUtils.FORMAT_SHOW_WEEKDAY | DateUtils.FORMAT_SHOW_YEAR);
    }

    private void removeRowOf(View actionView) {
        View rv = (View) actionView.getParent();
        ((ViewGroup) rv.getParent()).removeView(rv);
    }

    private void showHistory() {
        LinearLayout list = vlist();
        ArrayList<String[]> h = store.rows("hist2");
        if (h.isEmpty()) list.addView(emptyView("No history yet"));
        String lastDay = "";
        int shown = 0;
        for (String[] e : h) {
            if (e.length < 3 || shown >= 300) continue;
            shown++;
            final String[] ent = e;
            long ms;
            try {
                ms = Long.parseLong(ent[0]);
            } catch (NumberFormatException nfe) {
                ms = 0;
            }
            String day = dayLabel(ms);
            if (!day.equals(lastDay)) {
                list.addView(header(day));
                lastDay = day;
            }
            list.addView(row(ent[1].isEmpty() ? hostOf(ent[2]) : ent[1], ent[2],
                    v -> {
                        closePage();
                        navigate(ent[2]);
                    },
                    "\u2715", v -> {
                        store.removeHistory(ent[0], ent[2]);
                        removeRowOf(v);
                    }));
        }
        showPage("History", scroll(list), textBtn("Clear data", v -> showClearData()));
    }

    private void showBookmarks() {
        LinearLayout list = vlist();
        ArrayList<String[]> b = store.rows("bm");
        if (b.isEmpty()) list.addView(emptyView("No bookmarks yet.\nOpen a page and tap the star in the menu."));
        for (String[] e : b) {
            if (e.length < 2) continue;
            final String[] ent = e;
            list.addView(row(ent[0].isEmpty() ? hostOf(ent[1]) : ent[0], ent[1],
                    v -> {
                        closePage();
                        navigate(ent[1]);
                    },
                    "\u2715", v -> {
                        store.removeBookmark(ent[1]);
                        removeRowOf(v);
                    }));
        }
        showPage("Bookmarks", scroll(list));
    }

    private void showDownloads() {
        LinearLayout list = vlist();
        ArrayList<String[]> d = store.rows("dl");
        if (d.isEmpty()) list.addView(emptyView("No downloads yet"));
        for (String[] e : d) {
            if (e.length < 6) continue;
            final String[] ent = e;
            String sub = ent[4].equals("done") ? "Done" + (ent[5].isEmpty() ? "" : " \u2022 " + ent[5])
                    : ent[4].equals("downloading") ? "Downloading..." : "Failed";
            list.addView(row(ent[1], sub,
                    v -> {
                        if (ent[4].equals("done")) openFile(ent);
                    },
                    "\u2715", v -> {
                        store.removeDownload(ent[0]);
                        removeRowOf(v);
                        toast("Removed from the list (the file stays in Downloads)");
                    }));
        }
        showPage("Downloads", scroll(list));
    }

    private void openFile(String[] d) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(d[2]), d[3].isEmpty() ? "*/*" : d[3]);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            toast("No app can open this file");
        }
    }

    private View setting(String title, String value, View.OnClickListener l) {
        return row(title, value, l, null, null);
    }

    private void showSettings() {
        LinearLayout l = vlist();
        int ei = store.num("engine", 0);
        if (ei < 0 || ei >= ENGINE_NAMES.length) ei = 0;
        l.addView(setting("Search engine", ENGINE_NAMES[ei], v -> chooseEngine()));
        l.addView(setting("Text size", store.num("zoom", 100) + "%", v -> chooseZoom()));
        l.addView(setting("Dark mode for web pages", store.flag("dark", true) ? "On" : "Off", v -> {
            boolean on = !store.flag("dark", true);
            store.putFlag("dark", on);
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                for (Tab t : tabs) WebSettingsCompat.setAlgorithmicDarkeningAllowed(t.web.getSettings(), on);
            }
            closePage();
            showSettings();
        }));
        l.addView(setting("Clear browsing data", "History, cookies, cache", v -> showClearData()));
        l.addView(setting("Trojan connection", tStatus.length() > 40 ? tunnel != null ? "Connected" : "Not connected"
                : tStatus, v -> showTrojan()));

        String ver = "";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
        }
        PackageInfo wv = WebView.getCurrentWebViewPackage();
        l.addView(setting("About", "Trojan Browser " + ver
                + (wv != null ? " - Chromium " + wv.versionName : ""), v -> { }));
        showPage("Settings", scroll(l));
    }

    private void chooseEngine() {
        new AlertDialog.Builder(this).setTitle("Search engine")
                .setSingleChoiceItems(ENGINE_NAMES, store.num("engine", 0), (d, which) -> {
                    store.putNum("engine", which);
                    d.dismiss();
                    closePage();
                    showSettings();
                }).show();
    }

    private void chooseZoom() {
        String[] names = new String[ZOOMS.length];
        int sel = 2;
        for (int i = 0; i < ZOOMS.length; i++) {
            names[i] = ZOOMS[i] + "%";
            if (ZOOMS[i] == store.num("zoom", 100)) sel = i;
        }
        new AlertDialog.Builder(this).setTitle("Text size")
                .setSingleChoiceItems(names, sel, (d, which) -> {
                    store.putNum("zoom", ZOOMS[which]);
                    for (Tab t : tabs) t.web.getSettings().setTextZoom(ZOOMS[which]);
                    d.dismiss();
                    closePage();
                    showSettings();
                }).show();
    }

    private void showClearData() {
        final String[] items = {"Browsing history", "Cookies and site data", "Cached images and files",
                "Downloads list"};
        final boolean[] on = {true, true, true, false};
        new AlertDialog.Builder(this).setTitle("Clear browsing data")
                .setMultiChoiceItems(items, on, (d, i, checked) -> on[i] = checked)
                .setPositiveButton("Clear", (d, which) -> {
                    if (on[0]) store.put("hist2", "");
                    if (on[1]) {
                        CookieManager cm = CookieManager.getInstance();
                        cm.removeAllCookies(null);
                        cm.flush();
                        WebStorage.getInstance().deleteAllData();
                    }
                    if (on[2]) for (Tab t : tabs) t.web.clearCache(true);
                    if (on[3]) store.put("dl", "");
                    toast("Cleared");
                    if (cur != null && cur.ntp) refreshNtp();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ================================================================ Trojan connection

    private int proxyPort() {
        return tunnel != null ? localPort : -1;
    }

    private void setTStatus(String s, int color) {
        tStatus = s;
        tColor = color;
        updateTrojanUi();
    }

    private void updateTrojanUi() {
        if (trojanStatusView != null) {
            trojanStatusView.setText(tStatus);
            trojanStatusView.setTextColor(tColor);
        }
        if (trojanBtn != null) {
            trojanBtn.setText(tunnel != null ? "Disconnect" : connecting ? "Connecting..." : "Connect");
        }
        if (cur != null && cur.ntp) refreshNtp();
    }

    private void showTrojan() {
        LinearLayout l = vlist();
        l.setPadding(dp(16), dp(16), dp(16), dp(16));
        l.addView(label("Paste your trojan:// link. It is saved on this device until you change it, "
                + "and the browser connects with it automatically every time it starts.", 14, SUB));

        trojanLink = new EditText(this);
        trojanLink.setHint("trojan://...");
        trojanLink.setHintTextColor(SUB);
        trojanLink.setTextColor(TXT);
        trojanLink.setTextSize(14);
        trojanLink.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        trojanLink.setMinLines(3);
        trojanLink.setGravity(Gravity.TOP);
        trojanLink.setBackground(round(OMNI, 12));
        trojanLink.setPadding(dp(12), dp(10), dp(12), dp(10));
        trojanLink.setText(store.str("link", ""));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(MATCH, WRAP);
        ep.setMargins(0, dp(16), 0, dp(16));
        l.addView(trojanLink, ep);

        trojanBtn = pill("Connect", v -> trojanToggle());
        l.addView(trojanBtn, new LinearLayout.LayoutParams(MATCH, WRAP));

        trojanStatusView = label(tStatus, 14, tColor);
        trojanStatusView.setPadding(0, dp(16), 0, 0);
        l.addView(trojanStatusView, new LinearLayout.LayoutParams(MATCH, WRAP));

        showPage("Trojan connection", scroll(l));
        updateTrojanUi();
    }

    private void trojanToggle() {
        if (tunnel != null) {
            disconnect();
            return;
        }
        if (connecting) return;
        String l = trojanLink != null ? trojanLink.getText().toString().trim() : store.str("link", "");
        startTrojan(l);
    }

    private void startTrojan(final String l) {
        if (l.isEmpty()) {
            setTStatus("Paste your trojan:// link first", RED);
            finishBoot();
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            setTStatus("Please update \"Android System WebView\" from Play Store", RED);
            finishBoot();
            return;
        }
        store.put("link", l);                              // kept until you change it
        connecting = true;
        setTStatus("Connecting...", SUB);
        final Tunnel t = new Tunnel();
        new Thread(() -> {
            try {
                final int port = t.start(l);
                ui.post(() -> onConnected(t, port));
            } catch (final Exception e) {
                t.stop();
                final String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                ui.post(() -> onConnectFailed(msg));
            }
        }).start();
    }

    private void onConnected(Tunnel t, int port) {
        ProxyConfig cfg = new ProxyConfig.Builder()
                .addProxyRule("socks5://127.0.0.1:" + port)
                .build();
        ProxyController.getInstance().setProxyOverride(cfg, Runnable::run, () -> { });
        tunnel = t;
        localPort = port;
        connecting = false;
        setTStatus("Connected - all browser traffic goes through the Trojan server", GREEN);
        finishBoot();
    }

    private void onConnectFailed(String msg) {
        connecting = false;
        setTStatus("Failed: " + msg, RED);
        if (booting) {
            finishBoot();
            showTrojan();
        }
    }

    private void disconnect() {
        final Tunnel t = tunnel;
        tunnel = null;
        new Thread(t::stop).start();
        ProxyController.getInstance().clearProxyOverride(Runnable::run, () -> { });
        setTStatus("Not connected", SUB);
    }
}
