package com.trojanbrowser;

import android.app.Activity;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.format.Formatter;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

/**
 * Downloads a file into the public Downloads folder. When the Trojan tunnel is on
 * (proxyPort > 0) the download goes through it, exactly like page traffic.
 */
final class Downloader {
    private Downloader() { }

    static void toast(final Activity a, final String m) {
        a.runOnUiThread(() -> Toast.makeText(a, m, Toast.LENGTH_SHORT).show());
    }

    static void start(final Activity a, final Store st, final String url, final String ua,
                      final String cd, final String mimeHint, final String referer,
                      final int proxyPort) {
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) {
            toast(a, "This kind of link can't be downloaded");
            return;
        }
        final String guessed = Store.clean(URLUtil.guessFileName(url, cd, mimeHint));
        final String id = String.valueOf(System.currentTimeMillis());
        st.setDownload(new String[]{id, guessed, "", mimeHint == null ? "" : Store.clean(mimeHint), "downloading", ""});
        toast(a, "Downloading " + guessed);
        new Thread(() -> run(a, st, id, guessed, url, ua, mimeHint, referer, proxyPort)).start();
    }

    private static HttpURLConnection open(URL u, String ua, String referer, int proxyPort) throws IOException {
        HttpURLConnection c = (HttpURLConnection) (proxyPort > 0
                ? u.openConnection(new Proxy(Proxy.Type.SOCKS, new InetSocketAddress("127.0.0.1", proxyPort)))
                : u.openConnection());
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        if (ua != null) c.setRequestProperty("User-Agent", ua);
        String ck = CookieManager.getInstance().getCookie(u.toString());
        if (ck != null) c.setRequestProperty("Cookie", ck);
        if (referer != null && !referer.isEmpty()) c.setRequestProperty("Referer", referer);
        return c;
    }

    private static void run(Activity a, Store st, String id, String guessed, String url, String ua,
                            String mimeHint, String referer, int proxyPort) {
        String name = guessed;
        String mime = mimeHint;
        String size = "";
        Uri out = null;
        boolean ok = false;
        HttpURLConnection c = null;
        try {
            URL cur = new URL(url);
            for (int hop = 0; ; hop++) {
                c = open(cur, ua, referer, proxyPort);
                int code = c.getResponseCode();
                String loc = c.getHeaderField("Location");
                if (code >= 300 && code < 400 && loc != null && hop < 6) {
                    cur = new URL(cur, loc);
                    c.disconnect();
                    continue;
                }
                if (code / 100 != 2) throw new IOException("HTTP " + code);
                break;
            }
            String ct = c.getContentType();
            if (ct != null && (mime == null || mime.isEmpty() || mime.equals("application/octet-stream"))) {
                int semi = ct.indexOf(';');
                mime = (semi > 0 ? ct.substring(0, semi) : ct).trim();
            }
            if (mime == null || mime.isEmpty()) mime = "application/octet-stream";
            String cd2 = c.getHeaderField("Content-Disposition");
            if (cd2 != null) name = Store.clean(URLUtil.guessFileName(cur.toString(), cd2, mime));

            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
            out = a.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
            if (out == null) throw new IOException("Can't create the file");

            long total = 0;
            try (InputStream in = c.getInputStream();
                 OutputStream os = a.getContentResolver().openOutputStream(out)) {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) != -1) {
                    os.write(buf, 0, n);
                    total += n;
                }
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            a.getContentResolver().update(out, done, null, null);
            size = Formatter.formatShortFileSize(a, total);
            ok = true;
        } catch (Exception e) {
            if (out != null) {
                try {
                    a.getContentResolver().delete(out, null, null);
                } catch (Exception ignored) {
                }
                out = null;
            }
        } finally {
            if (c != null) c.disconnect();
        }
        st.setDownload(new String[]{id, Store.clean(name), out == null ? "" : out.toString(),
                mime == null ? "" : Store.clean(mime), ok ? "done" : "failed", size});
        toast(a, (ok ? "Download complete: " : "Download failed: ") + name);
    }
}
